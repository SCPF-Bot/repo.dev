package com.mlbb.assistant.capture

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import timber.log.Timber
import java.io.Closeable
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * Result from a single TFLite classification run on a cropped hero-slot bitmap.
 *
 * @param heroId     Domain hero ID (matches [com.mlbb.assistant.domain.model.Hero.id]).
 * @param confidence Softmax probability in [0, 1] — higher is more certain.
 */
data class ClassificationResult(
    val heroId: Int,
    val confidence: Float,
)

/**
 * On-device hero-portrait classifier backed by [MODEL_ASSET_PATH].
 *
 * ### Model
 * Architecture : MobileNetV3Small (Keras, converted via TensorFlow 2.20.0)
 * Input        : `[1, 224, 224, 3]` float32, pixels normalised to [−1, 1]
 * Output       : `[1, N]` float32 softmax probabilities (one entry per hero class)
 * Asset        : `assets/mlbb_hero_classifier.tflite` (~2 MB)
 *
 * The model must be stored **uncompressed** in the APK so Android can memory-map it
 * directly via [MappedByteBuffer]. This is enforced in `app/build.gradle.kts`:
 * ```
 * androidResources { noCompress += listOf("tflite") }
 * ```
 *
 * ### Label mapping
 * Output index → heroId mapping is loaded from [LABELS_ASSET_PATH].  The file
 * must have exactly N non-blank, non-comment lines — one heroId per line in the
 * same class order used during training.  A mismatch is logged as a warning and
 * [isAvailable] returns `false` to force the pHash fallback in [PortraitMatcher].
 *
 * ### Integration
 * [PortraitMatcher] calls [classify] first.  If the top-1 confidence is ≥
 * [PhaseDetectionConfig.TFLITE_ACCEPT_THRESHOLD] the result is returned directly,
 * skipping the more expensive pHash + histogram path.  See `misc.md` §13.
 *
 * ### Thread safety
 * [Interpreter] is NOT thread-safe.  [classify] must be called from a single
 * thread or with external synchronisation.  [PortraitMatcher.match] runs inside
 * `withContext(Dispatchers.Default)` — callers are responsible for not invoking
 * [classify] concurrently from different coroutines on the same instance.
 */
class HeroClassifier(context: Context) : Closeable {

    companion object {
        const val MODEL_ASSET_PATH  = "mlbb_hero_classifier.tflite"
        const val LABELS_ASSET_PATH = "hero_classifier_labels.txt"

        private const val INPUT_SIZE = 224          // model expects 224 × 224 RGB
        private const val NUM_THREADS = 2
        private const val TAG = "HeroClassifier"
    }

    private val interpreter: Interpreter?

    /** Ordered list of heroIds — index matches model output index. */
    val heroIds: List<Int>

    /** Number of output classes as reported by the model's output tensor. */
    val outputSize: Int

    /**
     * `true` when both the TFLite [Interpreter] and the label file loaded
     * successfully and their sizes agree.  [classify] returns an empty list
     * (triggering pHash fallback) when this is `false`.
     */
    val isAvailable: Boolean

    init {
        interpreter = runCatching {
            val buf = loadModelBuffer(context)
            val opts = Interpreter.Options().apply { setNumThreads(NUM_THREADS) }
            Interpreter(buf, opts)
        }.onFailure { e ->
            Timber.w(e, "$TAG: model load failed — HeroClassifier disabled")
        }.getOrNull()

        heroIds = runCatching {
            context.assets.open(LABELS_ASSET_PATH)
                .bufferedReader()
                .readLines()
                .mapNotNull { line ->
                    val trimmed = line.trim()
                    if (trimmed.isEmpty() || trimmed.startsWith("#")) null
                    else trimmed.toIntOrNull()
                }
        }.onFailure { e ->
            Timber.w(e, "$TAG: labels file '$LABELS_ASSET_PATH' missing — heroId mapping unavailable")
        }.getOrDefault(emptyList())

        outputSize = interpreter
            ?.runCatching { getOutputTensor(0).shape().getOrElse(1) { heroIds.size } }
            ?.getOrDefault(heroIds.size)
            ?: heroIds.size

        val sizesMatch = heroIds.isNotEmpty() && heroIds.size == outputSize
        if (!sizesMatch && interpreter != null) {
            Timber.w(
                "$TAG: label count (${heroIds.size}) ≠ model output size ($outputSize) — " +
                    "update '$LABELS_ASSET_PATH' to match the retrained model"
            )
        }

        isAvailable = interpreter != null && sizesMatch
        Timber.i("$TAG: init — isAvailable=$isAvailable, outputSize=$outputSize, labels=${heroIds.size}")
    }

    /**
     * Classifies [bitmap] and returns the top-[topK] hero predictions.
     *
     * Returns an empty list when [isAvailable] is `false` or inference fails,
     * which causes [PortraitMatcher] to fall back to pHash + histogram matching.
     *
     * @param bitmap The cropped slot image — any size; resized to [INPUT_SIZE]×[INPUT_SIZE] internally.
     * @param topK   Maximum number of results to return (default 3).
     */
    fun classify(bitmap: Bitmap, topK: Int = 3): List<ClassificationResult> {
        if (!isAvailable) return emptyList()
        val interp = interpreter ?: return emptyList()

        val resized = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)
        val inputTensor = preprocessBitmap(resized)
        if (resized !== bitmap) resized.recycle()

        val outputTensor = Array(1) { FloatArray(outputSize) }
        return runCatching {
            interp.run(inputTensor, outputTensor)
            val scores = outputTensor[0]
            buildList {
                scores.forEachIndexed { idx, score ->
                    if (idx < heroIds.size) add(ClassificationResult(heroIds[idx], score))
                }
            }
                .sortedByDescending { it.confidence }
                .take(topK)
        }.onFailure { e ->
            Timber.w(e, "$TAG: inference failed — falling back to pHash")
        }.getOrDefault(emptyList())
    }

    override fun close() {
        interpreter?.close()
    }

    // ── Internal helpers ───────────────────────────────────────────────────

    /**
     * Converts a [INPUT_SIZE]×[INPUT_SIZE] [Bitmap] to the 4-D float tensor
     * expected by MobileNetV3Small: `[1, H, W, 3]`, each channel normalised to [−1, 1].
     *
     * Normalisation formula: `pixel / 127.5 − 1.0`  (standard TensorFlow MobileNet preprocessing).
     */
    private fun preprocessBitmap(bitmap: Bitmap): Array<Array<Array<FloatArray>>> {
        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        bitmap.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)

        val input = Array(1) { Array(INPUT_SIZE) { Array(INPUT_SIZE) { FloatArray(3) } } }
        pixels.forEachIndexed { i, px ->
            val y = i / INPUT_SIZE
            val x = i % INPUT_SIZE
            input[0][y][x][0] = ((px shr 16 and 0xFF) / 127.5f) - 1f  // R
            input[0][y][x][1] = ((px shr 8  and 0xFF) / 127.5f) - 1f  // G
            input[0][y][x][2] = ((px        and 0xFF) / 127.5f) - 1f  // B
        }
        return input
    }

    /**
     * Memory-maps the TFLite model from assets.  Memory-mapping avoids copying the
     * ~2 MB model into the Java heap and is required for the [Interpreter] to use
     * NNAPI or GPU delegates safely.
     */
    private fun loadModelBuffer(context: Context): MappedByteBuffer {
        val fd = context.assets.openFd(MODEL_ASSET_PATH)
        return FileInputStream(fd.fileDescriptor).use { fis ->
            fis.channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        }
    }
}

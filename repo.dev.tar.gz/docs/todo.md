# TODO — MLBB Draft Assistant

> **Status:** Living, actionable backlog. Every item is concrete and verifiable.
> Pull an item before coding; check it off when merged; reflect new capabilities in [`features.md`](./features.md).
>
> **Priority:** P0 critical · P1 high · P2 normal · P3 nice-to-have
> **Effort:** S ≤ 2 h · M ≤ 1 day · L > 1 day
>
> Strategic phasing → [`roadmap.md`](./roadmap.md) · Shipped capabilities → [`features.md`](./features.md)

---

## 1. Technical-debt register (TD-xx)

Inline `TD-xx` tags mark resolved debt at the fix site. Next new item: **TD-16**.

| ID | Item | State | Where |
|---|---|---|---|
| TD-01 | `hasCCUlt` field replaces hardcoded CC name list | done | `Hero.kt`, `HeroEntity.kt`, `CompositionAnalyzer.kt`, migration v2→v3 |
| TD-02 | Personal hero-pool proficiency multiplier + 6-item builds | done | `DraftScorer.kt`, `Proficiency.kt`, `BuildAdvisor.kt` |
| TD-03 | CV thresholds centralised in config | done | `PhaseDetectionConfig.kt`, `PhaseDetector.kt` |
| TD-04 | Normalised luminance slot-fill threshold | done | `FrameProcessor.kt` |
| TD-05 | Dataset-derived dynamic scoring bounds | done | `DraftScorer.kt` (`computeBounds`) |
| TD-06 | Explicit `Dispatchers.IO` in repository suspend fns | done | `HeroRepositoryImpl.kt` |
| TD-07 | SavedStateHandle-backed search/filter | done | `HeroPoolViewModel.kt` |
| TD-08 | Parallel lazy portrait-hash preload + hybrid match | done | `PortraitMatcher.kt` |
| TD-09 | *(permanent gap — unassigned reservation)* | closed | n/a |
| TD-10 | Paging 3 hero grid | done | `HeroRepositoryImpl.kt`, `HeroDao.kt`, `GetPagedHeroesUseCase.kt` |
| TD-11 | Mutex-guarded crash-log writes | done | `CrashLogStore.kt` |
| TD-12 | Bubble position persistence | done | `OverlayService.kt` |
| TD-13 | WorkManager periodic hero-data sync | done | `HeroSyncWorker.kt`, `MLBBApplication.scheduleHeroSync()` |
| TD-14 | OCR-calibrated ban slot coords + rank-aware `BanDraftType`/`BanSlotTemplates` + `processFrame(banDraftType)` | done | `capture/SlotRegions.kt`, `capture/FrameProcessor.kt`, `assets/draft_ui_map.json` |
| TD-15 | TFLite hero classifier integrated as primary matching path in `PortraitMatcher`; `HeroClassifier` wraps `mlbb_hero_classifier.tflite`; `hero_classifier_labels.txt` maps index→heroId; `TFLITE_ACCEPT/TENTATIVE_THRESHOLD` in `PhaseDetectionConfig` | done | `capture/HeroClassifier.kt`, `capture/PortraitMatcher.kt`, `capture/PhaseDetectionConfig.kt`, `assets/hero_classifier_labels.txt` |

---

## 2. Correctness & robustness

- [ ] **P1/M** Verify `/schemas` JSON files (v1, v2, v3) are committed — run `./gradlew :app:kspDebugKotlin` if missing. Required for safe Room migrations.
- [ ] **P1/M** Add Room migration test (v1→v3) using `MigrationTestHelper`. Guards against silent data loss on upgrade.
- [ ] **P1/M** Validate `SlotRegions` / `draft_ui_map.json` against multiple aspect ratios (18:9, 19.5:9, 20:9, tablets); document the supported set.
- [ ] **P2/M** Handle `MediaProjection` revocation / `onStop` gracefully — stop capture, surface "capture unavailable" in overlay status bar.
- [ ] **P2/S** Guard `scoreSafety` against `enemies.size == 0` — add unit test to lock behaviour.
- [ ] **P2/S** Confirm `adaptiveWeights` never violates the `ScoreWeights` sum-to-1 invariant for all `pickIndex`; add property test.
- [ ] **P2/M** Define behaviour when `MetaApi` returns partial/garbage data — DTO validation + reject-and-keep-existing flow.
- [ ] **P3/S** Make `inferFromBanCount` thresholds in `RankRuleEngine` named constants instead of inline literals.

---

## 3. Architecture & maintainability

- [ ] **P1/L** Introduce a `:domain` and `:data` Gradle module split to enforce the dependency rule at compile time.
- [ ] **P2/M** Expose `WeightCalibrator` in Settings UI — the engine exists but has no UI surface and no minimum-sample gate.
- [ ] **P2/S** Unify `DraftScorer.computeScore` and `score` into a single entry point with a `simplified = true` parameter. Current `@VisibleForTesting` annotation is the interim fix (see `misc.md` §2).

---

## 4. Testing

- [ ] **P1/M** Compose UI tests for Draft, HeroList, Settings, and Permission Wizard.
- [ ] **P1/M** Instrumentation test for the overlay foreground-service start/stop lifecycle.
- [ ] **P2/M** Unit tests for `WeightCalibrator`, `DraftPatternAnalyzer`, `EnemyIntentAnalyzer`, `WinConditionGenerator`, `BuildAdvisor`, `DraftScoreCalculator`.
- [ ] **P2/M** `FrameProcessor` slot-dedupe and throttle tests with synthetic bitmaps (Robolectric). Include a benchmark validating the `copyPixelsToBuffer` improvement and `ConcurrentHashMap` correctness under concurrent access.
- [ ] **P2/S** `DraftExporter` round-trip serialisation test.
- [ ] **P3/S** Snapshot tests for key Compose components.

---

## 5. CI / tooling / release

- [ ] **P2/M** Signed-release workflow + R8 mapping upload (enables stack-trace deobfuscation).
- [ ] **P2/S** Verify ProGuard keep rules cover kotlinx.serialization DTOs, Room entities, and Hilt-generated classes; test on a minified build. Run `./gradlew assembleRelease` to confirm.
- [ ] **P2/S** Run `./gradlew detektBaseline` and commit the generated `config/detekt/baseline.xml`.
- [ ] **P2/S** Remove Gson dependency once a minified-build smoke test confirms kotlinx.serialization covers all JSON entry points (see `misc.md` §10).
- [ ] **P3/S** Generate a baseline profile for startup performance.

---

## 6. Observability

- [x] **P2/M** Embedded debug companion via **Pluto v3.0.0** (https://github.com/androidPluto/pluto). Debug APK shows a persistent floating bubble; tap to open: log viewer (all Timber output via `PlutoTimberTree`), network inspector (OkHttp via `PlutoOkhttpInterceptor`), crash/exception capture, Room DB browser (`PlutoRoomsDBWatcher`), DataStore viewer (`PlutoDatastoreWatcher`), SharedPrefs viewer. Release uses no-op stubs — zero overhead. No Play Store / Google Play Services dependency. Wired in `MLBBApplication`, `NetworkModule`, `DatabaseModule`, `AppModule`, `libs.versions.toml`, and `build.gradle.kts`.
- [ ] **P2/S** Add a "Share logs" action from `LogScreen` via the existing FileProvider.
- [ ] **P3/S** Structured event logging for detection accuracy (phase-detect confidence, match confidence) to inform tuning.

---

## 7. UX & product polish

- [ ] **P2/M** Surface self-status in the overlay: "capture unavailable", "meta data stale (N days)", "accessibility service off".
- [ ] **P2/M** No-capture (manual) mode parity audit — verify every autonomous path has a manual equivalent and document it.
- [ ] **P2/S** Empty/error states for HeroList, MetaBoard, and History screens.
- [ ] **P3/M** Light theme + accent presets.
- [ ] **P3/M** Landscape/tablet overlay layout.
- [ ] **P3/S** First-run interactive draft simulation tied to `isSimulation`.

---

## 8. Data & content

- [ ] **P1/M** Confirm `META_API_BASE_URL` (`https://api.mlbb-assistant.com/`) is live or document the bundled-seed-only mode clearly, including a staleness indicator in MetaBoard.
- [ ] **P2/M** Establish an update cadence/source for `default_heroes.json` (counters/synergies/tiers drift each patch).
- [ ] **P2/S** Add `lastUpdated`/patch-version metadata to the meta snapshot and display it in MetaBoard.
- [ ] **P3/M** Community-sourced counter/synergy contributions with confidence weighting.

---

## 9. Documentation

- [ ] **P2/M** Wire `AspectRatioPreset` from DataStore into `OverlayCaptureCoordinator` — apply coordinate offset to `SlotRegions` crops when preset is STANDARD_16_9 (pillarbox inset) or ULTRAWIDE_21_9. Currently the preset is stored but not yet read by the CV pipeline.
- [ ] **P2/S** Document the CV calibration workflow (how to remap `SlotRegions` for a new device) in `overview.md` or a new `docs/cv-calibration.md`.
- [ ] **P3/S** Add ADRs (Architecture Decision Records) for the key calls listed in `overview.md` §8.

---

## 10. Library adoption — pending items

> Adopted libraries are recorded in `features.md` §11. Only items with remaining integration work are listed here.

| Library | Status | Next step |
|---|---|---|
| KilianB/JImageHash | ⚙️ In Gradle | Benchmark false-positive rate against portrait test set; keep dHash fallback (see `misc.md` §9) |
| ML Kit Object Detection | ⚙️ In Gradle | For portrait *region detection* (bounding boxes) — separate from `HeroClassifier`. Collect 500+ annotated crops → train SSD model → integrate into `HeroPortraitObjectDetector` (see `roadmap.md` RA-05) |
| TFLite Hero Classifier | ✅ Integrated | `HeroClassifier.kt` wraps `mlbb_hero_classifier.tflite`; wired as primary path in `PortraitMatcher`; `hero_classifier_labels.txt` maps output index→heroId; see `misc.md` §13 |
| p3hndrx/MLBB-API | 📋 Deferred | Backend stability verification required |
| ridwaanhall/api-mobilelegends | 📋 Deferred | API liveness confirmation first (blocks RA-03) |

---

## How to use this file

- Pull an item here before coding; check it off when merged; reflect any new capability in [`features.md`](./features.md).
- When you create new technical debt, add a `TD-xx` tag in source **and** a row in §1 in the same commit. Next available: **TD-14**.
- Keep priorities honest: promote or demote items as the product situation changes.
- Completed items are removed from this file; their resolution lives in git history and `roadmap.md`.

package com.mlbb.assistant.presentation.main

import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import com.mlbb.assistant.presentation.common.theme.MLBBAssistantTheme
import com.mlbb.assistant.presentation.overlay.OverlayService
import com.mlbb.assistant.presentation.shell.AppShell
import com.mlbb.assistant.service.VoiceAlertService
import com.mlbb.assistant.utils.DevLoggerManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var voiceAlertService: VoiceAlertService

    /**
     * Launched after the user grants the screen-capture permission dialog.
     * We pass the result directly to OverlayService so it can set up
     * MediaProjection and start the autonomous capture loop — without
     * keeping a local ScreenCaptureManager here.
     *
     * P0-03 fix: replaced `result.data!!` with a safe early-return pattern.
     * The manual `!= null` guard was correct but used `!!` anyway, which
     * bypasses Kotlin's smart-cast and will crash if `data` is somehow null
     * (e.g. under aggressive R8 class rewriting in release builds, or if the
     * activity-result contract changes). Using `?: return@registerForActivityResult`
     * is both safer and idiomatic.
     */
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val data = result.data ?: return@registerForActivityResult
        OverlayService.startWithProjection(this, result.resultCode, data)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Developer mode defaults to ON. On a fresh install the companion verbose
        // logger is not yet installed, so prompt the user to install it now.
        // DevLoggerManager tracks whether the prompt has already been shown via
        // SharedPreferences and skips repeat prompts on subsequent launches.
        DevLoggerManager.promptInstallIfNeeded(this)

        setContent {
            MLBBAssistantTheme {
                AppShell(
                    onStartOverlay   = { startOverlay() },
                    onRequestCapture = { requestScreenCapture() }
                )
            }
        }
    }

    override fun onDestroy() {
        voiceAlertService.shutdown()
        super.onDestroy()
    }

    /**
     * Called when the user taps "Start Draft".
     *
     * Steps:
     * 1. Verify overlay permission — if missing, open the system settings page.
     * 2. Start OverlayService immediately (bubble appears).
     * 3. Request screen-capture permission so autonomous detection can start.
     *    The result flows back through [projectionLauncher] → OverlayService.
     */
    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            OverlayService.start(this) // service will show a prompt via OverlayPermissionActivity
            return
        }
        OverlayService.start(this)
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}

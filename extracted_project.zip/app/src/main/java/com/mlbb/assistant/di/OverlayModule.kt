package com.mlbb.assistant.di

import android.content.Context
import android.provider.Settings
import com.mlbb.assistant.domain.OverlayController
import com.mlbb.assistant.presentation.overlay.OverlayService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object OverlayModule {

    @Provides
    @Singleton
    fun provideOverlayController(
        @ApplicationContext context: Context
    ): OverlayController = object : OverlayController {
        override fun start() {
            if (Settings.canDrawOverlays(context)) OverlayService.start(context)
        }
        // Pass 3: OverlayService.stop() wraps Context.stopService() which returns Boolean.
        // Expression body would infer Boolean, conflicting with interface's Unit return type.
        // Block body discards the Boolean and satisfies fun stop(): Unit.
        override fun stop() {
            OverlayService.stop(context)
        }
    }
}
